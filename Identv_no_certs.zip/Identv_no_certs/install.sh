#!/usr/bin/bash
echo "Wees eerst zeker dat u de Identv map in de root van de gebruikersmap heeft gestoken, anders zal het script niet werken."
echo "Poging tot automatische installatie en configuratie van het Identv project voor een raspberry pi 4 met Raspberry pi os gebaseerd op debian 11."
echo "python3 en python3-pip installatie verifiëren"
sudo apt install python3 python3-pip -y
echo "installeren van aanvullende pythonmodules"
pip3 install pyOpenSSL
echo "python3 en python3-pip geïnstalleerd"
echo "stap 1 aanmaken van een CSR en sleutel"
echo "rechten instellen"
chmod 777 manufacturer/gencsr.py
chmod 777 iot-edge/run.sh
echo "aanmaken CSR en sleutel"
python3 manufacturer/gencsr.py
echo "CSR en key aangemaakt, script wordt nu verwijderd voor veiligheidsredenen"
echo "webserver certificaten toevoegen aan de lokale machine"
sudo cp AM_IG_rootcert/*.crt /usr/local/share/ca-certificates
sudo update-ca-certificates
echo "certificaten toegevoegd"
rm -rf manufacturer/gencsr.py
echo "poging tot automatische installatie van golang 1.18.2 voor arm64"
echo "downloaden"
wget https://go.dev/dl/go1.18.2.linux-arm64.tar.gz
echo "installeren"
sudo tar -C /usr/local -xzf go1.18.2.linux-arm64.tar.gz
echo "download verwijderen"
rm -rf go1.18.2.linux-arm64.tar.gz
echo ".profile updaten"
#sudo chmod 777  ~/.profile
#echo "HOME=$HOME:/usr/local/go/bin" >> ~/.profile
#echo "GOPATH=$PATH:/go" >> ~/.profile
#sudo chmod 421 ~/.profile
#echo ".profile geupdate dit zal pas werken na een herstart"
echo "kodi installeren"
sudo apt install kodi
echo "csr en key naar kodi kopiëren"
mkdir ~/.kodi
mkdir ~/.kodi/certs
cp manufacturer/* ~/.kodi/certs/
echo "tot zo ver de automatische installatie"
echo "open kodi en importeer de extenties vanuit de Identv map"
echo "herstart het systeem, dit script zal niet meer werken nadat het 1 keer is uitgevoerd."
echo "lees de readme, daar staan 2 lijnen in die nog onderaan in de .profile file moeten komen "
read -p "druk op enter om af te sluiten."
sudo reboot
