import os
import time
import socket
import OpenSSL
from flask import Flask, request

# set up globals
app = Flask(__name__)

# get real IP address
def get_ip_address():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    return s.getsockname()[0]
ip_address = get_ip_address()

# define routes
@app.route('/', methods=['GET','POST'])
def index():
    return """To use this server to sign CSRs,
    curl {}:5000/csr -F csr=@<path-to-csr> > <path-to-cert>
""".format(ip_address)

@app.route('/csr', methods=['POST'])
def sign():
    """
    http://docs.ganeti.org/ganeti/2.7/html/design-x509-ca.html#x509-certificate-from-certificate-signing-request
    """
    # get latest intermediary and load them
    ca_path = os.path.expanduser("/home/forgerock/certs")
    f_ca_cert = os.path.join(ca_path, "myCERT.pem")#root cert
    f_ca_key = os.path.join(ca_path, "myCAkey.pem")#root cert private key
    if not os.path.exists(f_ca_cert) or not os.path.exists(f_ca_key):
        return b'Intermediary not configured.\n'

    ca_cert = OpenSSL.crypto.load_certificate(
        OpenSSL.crypto.FILETYPE_PEM,
        open(f_ca_cert, 'r').read())
    ca_key = OpenSSL.crypto.load_privatekey(
        OpenSSL.crypto.FILETYPE_PEM,
        open(f_ca_key, 'r').read())

    #signed = bytes(None)
    signed = ""
    try:

        f_csr = request.files.get('csr')#works
        csr = OpenSSL.crypto.load_certificate_request(
            OpenSSL.crypto.FILETYPE_PEM,
            f_csr.stream.read())
        #print(csr.get_subject().ST)#print csr password
        if(csr.get_subject().ST == "S3ECH0nAUChLF9bf"):#controleer op deze string in de csr, als deze overeen komt mag de server een getekend certificaat terug sturen.
            cert = OpenSSL.crypto.X509()
            cert.set_subject(csr.get_subject())
            cert.set_serial_number(1)
            cert.gmtime_adj_notBefore(0)
            cert.gmtime_adj_notAfter(365 * 24 * 60 * 60)
            cert.set_issuer(ca_cert.get_subject())
            cert.set_pubkey(csr.get_pubkey())
            cert.sign(ca_key, "sha1")
            signed = OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, cert)
            print("signed csr returning soon")
            #print("signed " + str(signed))
        else:
            print("invalid csr parameters")
            return(b'invalid certificate parameters! signing denied')
    except:
        return b'An error occurred with the csr-signer.\n'
    return signed

@app.route('/tell', methods=['POST'])#wordt niet actief gebruikt in het project maar is makkelijk om te debuggen.
def tell():
    """
        This is just a convenience endpoint to make sharing data with 
        the server admin is easier.
        Usage:
            curl <ip-address>:5000/tell -d "msg=some handy message.\n"
    """
    msg = request.form.get('msg')
    print("New message: {}".format(msg))
    open(str(time.time())+'.msg', 'w').write(msg)
    return b''

# start server
if __name__ == '__main__':
    app.run(host=ip_address, port=5000)
