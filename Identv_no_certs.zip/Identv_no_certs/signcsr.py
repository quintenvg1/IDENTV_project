#this script in run outside of the kodi container for convenience sake pyOpenSSL is not installed in KODI
#run with os.system("python3 /home/pi/.kodi/signcsr.py") after pointing the internal path
#in .kodi certs should be a CSR file, key is optional?
import os
from os.path import exists
import OpenSSL
import requests
user = os.getlogin()#works also in kodi
homedir = ("/home/"+user)#/home/user
os.chdir((homedir+"/.kodi"))#location of .kodi root

file_exists = exists("certs/myCERT.pem")
if(file_exists == False):
    url = "http://identit-stage02.nynox.lcl:5000/csr"
    csrfile = "certs/myCSR.csr"#presigned csr file from factory
    f = open(csrfile, "r")
    csr = f.read()
    f.close()
    csr = csr.encode("UTF-8")
    bytes(csr)

    csr_f = OpenSSL.crypto.load_certificate_request(
        OpenSSL.crypto.FILETYPE_PEM,
        open(csrfile, 'r').read())
    

    response = requests.post("http://identit-stage02.nynox.lcl:5000/csr", files={"csr":csr})
    allesdict = response.__dict__
    signed_cert = allesdict["_content"].decode("UTF-8")
    print("writing signed cert to file named myCERT.pem in script dir")
    print(signed_cert)
    certificate = "certs/myCERT.pem"
    f = open(certificate, "w")
    f.write(signed_cert)
    f.close()

