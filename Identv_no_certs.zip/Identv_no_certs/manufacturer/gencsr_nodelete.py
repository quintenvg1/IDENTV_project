#dit script dient om een csr file aan te maken die de set-top box zal gaan sturen naar de CA server om een signed cert terug te krijgen.
from OpenSSL.SSL import FILETYPE_PEM
from OpenSSL.crypto import (dump_certificate_request, dump_privatekey, PKey, TYPE_RSA, X509Req)
import re
import os
user = os.getlogin()
homedir = ("/home/"+user)
print("dit script werkt alleen als het in de Identv folder zit in de root van de gebruiker")
def create_csr(csr_file_path = (homedir+"/Identv/manufacturer/myCSR.csr"), cert_file_path = (homedir+"/Identv/manufacturer/myCERT.pem")):
    private_key_path = re.sub(r".(pem|crt)$", ".key", cert_file_path, flags=re.IGNORECASE)
 
    # maak public/private key
    key = PKey()
    key.generate_key(TYPE_RSA, 2048)
 
    # Generate CSR
    req = X509Req()
    req.get_subject().CN = 'BE'
    req.get_subject().O = 'Antwerpen'
    req.get_subject().OU = 'IdenTV'
    req.get_subject().L = 'Kontich'
    req.get_subject().ST = 'IAM_A_PASSWORD'#csr|certificaat paswoord
    req.get_subject().C = 'EU'
    req.set_pubkey(key)
    req.sign(key, 'sha256')
 
    #schrijf de files weg
    with open(csr_file_path, 'wb+') as f:
        f.write(dump_certificate_request(FILETYPE_PEM, req))
    with open(private_key_path, 'wb+') as f:
        f.write(dump_privatekey(FILETYPE_PEM, key))

create_csr()
print("generated csr and key file place those in .kodi folder when you have it. this script should now be removed to prevent cert data from leaking.")
