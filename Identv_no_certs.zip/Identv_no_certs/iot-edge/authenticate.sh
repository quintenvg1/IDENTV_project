./run.sh example "thing/cert-registration/" -url "http://identit-stage02.nynox.lcl:8081/openam" -realm "/alpha" -name "raspberrypi" -tree "thing_reg_tree" -audience "/alpha" -key cat ./examples/resources/eckey1.key.pem -cert cat ./examples/resources/dynamic-gateway.cert.pem -secrets cat ./examples/resources/public.jwks
exit
