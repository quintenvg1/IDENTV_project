## Tree data

Anvil will use the data contained in this folder to create AM Auth Trees.

When a tree node is created:

    * the name is taken from the json file name
    * the configuration is taken from the contents of the JSON file.
    This is equivalent to the data sent with the REST request to create a tree.
