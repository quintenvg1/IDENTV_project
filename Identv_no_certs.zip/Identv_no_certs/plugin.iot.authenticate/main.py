# Module: main
# Author: IdentIT
# Created on: 2021
#kodi context is in /home
import sys
import xbmcgui
import xbmcplugin
import subprocess
#quinten's custom imports
import re
import json
import os
#test if a certificate is present
global homedir
user = os.getlogin()#works also in kodi
homedir = ("/home/"+user)#/home/user
cert_exsists = os.path.exists((homedir+'/.kodi/certs/myCERT.pem'))

#generate certificate if one does not exist
if(cert_exsists == False):
    os.chdir((homedir+"/Identv"))
    os.system("python3 signcsr.py")#get the csr signed


os.chdir((homedir+"/Identv/iot-edge"))#where the iot-edge root is located
if __name__ == '__main__':
    dialog = xbmcgui.Dialog()
    #script_location = dialog.input('Enter location of go script',defaultt="Documenten/kodi_extensions/plugin.iot.authenticate", type=xbmcgui.INPUT_ALPHANUM)#not needed anymore
    #script_location = dialog.input('Enter location of go script',defaultt="/home/pi/Documenten/identv/authenticate.go", type=xbmcgui.INPUT_ALPHANUM)

    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Kodi', 'Running script...')
    #get cert test in kodi
    #get signed cert in .kodi folder
    try:
        dialog = xbmcgui.Dialog()
        #access_token = str(subprocess.check_output(('./run.sh example "thing/cert-registration/" -url "https://identit-stage02.nynox.lcl:9443/openam" -realm "/alpha" -name "raspberrypi" -tree "thing_reg_tree" -audience "/alpha" -key cat '+homedir+"/.kodi/certs/myKEY.pem"' -cert cat '+homedir+'/.kodi/certs/myCERT.pem -secrets cat ./examples/resources/public.jwks'), shell=True))
        access_token = str(subprocess.check_output(('./run.sh example "thing/cert-registration/" -url "https://identit-stage02.nynox.lcl:9443/openam" -realm "/alpha" -name "raspberrypi" -tree "thing_reg_tree" -audience "/alpha" -key cat '+homedir+"/.kodi/certs/myKEY.pem"' -cert cat '+homedir+'/.kodi/certs/myCERT.pem -secrets cat ./examples/resources/public.jwks'), shell=True))
        access_token_jsonstring = re.search('{(.*)}', access_token)#regex to generate json from printout
        access_token_json = "{"+access_token_jsonstring.group(1)+"}" #now the data is in json format and can easily be transformed into a python dict
        access_token_dict = json.loads(access_token_json)
        access_token = access_token_dict["access_token"]
        user_data_path = xbmc.translatePath('special://home')#works returns only an access token :D

        pDialog.update(50, 'Persisting token')

        f = open(user_data_path + "access_token", "w")
        f.write(access_token)
        f.close()

        pDialog.update(100, 'Done')

         
        dialog.notification('Access token', (user+' you now have a token'), xbmcgui.NOTIFICATION_INFO, 2500)
    except FileNotFoundError:
        dialog = xbmcgui.Dialog()
        dialog.notification('Error', 'Script not found', xbmcgui.NOTIFICATION_ERROR, 2500)
    except Exception as error:
        dialog = xbmcgui.Dialog() 
        dialog.notification('Error', 'An exception occurred: {}'.format(error), xbmcgui.NOTIFICATION_ERROR, 2500) 
    finally:
        pDialog.close()
