PATH=$PATH:/usr/local/go/bin
GOPATH=$HOME:/go
plaats bovenstaande lijnen onderaan in de .profile file van de gebruiker die kodi zal draaien
