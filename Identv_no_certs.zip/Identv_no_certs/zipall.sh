zip -r plugin.iot.authenticate.zip plugin.iot.authenticate/
zip -r plugin.video.server.zip plugin.video.server/